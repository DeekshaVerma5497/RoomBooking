package com.roombooking.dao;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.roombooking.model.Booking;
import com.roombooking.model.DatePick;
import com.roombooking.model.Room;

@Repository("dao")
public class BookingDAOImpl implements BookingDAO {

	@PersistenceContext
	private EntityManager em;

	@Transactional
	public void insertRoom(Room room) {
		em.persist(room);

	}

	@Transactional
	public void insertDate(DatePick datePick) {
		em.persist(datePick);
	}

	@Transactional
	public List<DatePick> displayRDates(int roomNo) {
		List<DatePick> list = new ArrayList<DatePick>();
		Query query = em.createQuery("from DatePick");
		list = query.getResultList();
		return list;

	}

	@Transactional
	public List<Room> displayRooms() {
		List<Room> roomL = new ArrayList<Room>();
		Query query = em.createQuery("from Room");
		roomL = query.getResultList();
		return roomL;
	}

	@Transactional
	public void bookRoom(int roomNo, String[] bDate) {
		System.out.println(roomNo);
		Room r;
		//List<Booking> bList=new ArrayList<Booking>();
		r=em.find(Room.class, roomNo);
		System.out.println(r.getRO_id());
		
		//Room room=new Room();
		
		
		Booking b = new Booking();
		for(String bd:bDate) {
			int d=Integer.parseInt(bd);
			DatePick dp=em.find(DatePick.class, d);
			System.out.println(dp.getADate());
			b.setRB_Date(dp.getADate());
			b.setRB_Booked("Y");
			b.setRoom(r);
		}
		em.persist(b);
	//success(r);
	}

	/*@Transactional
	private void success(Room r) {
		Booking b;
		Query query=em.createQuery("from Booking");
		List<Booking> bList=new ArrayList<Booking>();
		bList=query.getResultList();
		
		for(Booking bl:bList) {
			System.out.println(bl);
		}
		r.setbList(bList);*/
		
		
	//}

}

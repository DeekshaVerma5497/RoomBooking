package com.roombooking.service;

import java.util.List;

import com.roombooking.model.Booking;
import com.roombooking.model.DatePick;
import com.roombooking.model.Room;

public interface ServiceM {

	public List<DatePick> displayRDates(int roomNo);

	public void createTables();

	public List<Room> displayRooms();

	public void bookRoom(int roomNo, int bDate);

	public List<Booking> bookedRoom();



}

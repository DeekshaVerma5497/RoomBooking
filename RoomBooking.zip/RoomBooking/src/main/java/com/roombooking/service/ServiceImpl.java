package com.roombooking.service;

import java.lang.annotation.Annotation;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.roombooking.dao.BookingDAO;
import com.roombooking.model.Booking;
import com.roombooking.model.DatePick;
import com.roombooking.model.Room;

@Service
@Qualifier("servicem")
public class ServiceImpl implements ServiceM {
	@Autowired(required = true)
	private BookingDAO dao;

	public List<DatePick> displayRDates(int roomNo) {
		return dao.displayRDates(roomNo);
	}

	public void createTables() {
		Room room = new Room();
		room.setRO_roomNo("1001");
		dao.insertRoom(room);

		Room room1 = new Room();
		room1.setRO_roomNo("1002");
		dao.insertRoom(room1);

		DatePick datePick1 = new DatePick();
		datePick1.setADate("1 March");
		dao.insertDate(datePick1);
		
		DatePick datePick2 = new DatePick();
		datePick2.setADate("2 March");
		dao.insertDate(datePick2);
		
		DatePick datePick3 = new DatePick();
		datePick3.setADate("3 March");
		dao.insertDate(datePick3);
		
		DatePick datePick4 = new DatePick();
		datePick4.setADate("4 March");
		dao.insertDate(datePick4);
		
		DatePick datePick5 = new DatePick();
		datePick5.setADate("5 March");
		dao.insertDate(datePick5);
		
		

	}

	public List<Room> displayRooms() {
		return dao.displayRooms();

	}

	public void bookRoom(int roomNo, int bDate) {
		dao.bookRoom(roomNo,bDate);
		
	}
	
	public List<Booking> bookedRoom() {
		return dao.bookedRoom();
	}



}

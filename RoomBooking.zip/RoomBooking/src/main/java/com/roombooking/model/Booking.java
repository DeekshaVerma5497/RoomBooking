package com.roombooking.model;


import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int RB_Id;
	
	private String RB_Date;
	private String RB_Booked;
	
	
	@ManyToOne
	private Room room;
	
	
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	public int getRB_Id() {
		return RB_Id;
	}
	public void setRB_Id(int rB_Id) {
		RB_Id = rB_Id;
	}
	public String getRB_Date() {
		return RB_Date;
	}
	public void setRB_Date(String rB_Date) {
		RB_Date = rB_Date;
	}
	public String getRB_Booked() {
		return RB_Booked;
	}
	public void setRB_Booked(String rB_Booked) {
		RB_Booked = rB_Booked;
	}
	
	public Booking() {
		// TODO Auto-generated constructor stub
	}
	public Booking(int rB_Id, String rB_Date, String rB_Booked) {
		super();
		RB_Id = rB_Id;
		RB_Date = rB_Date;
		RB_Booked = rB_Booked;
	}
	
	
	
}

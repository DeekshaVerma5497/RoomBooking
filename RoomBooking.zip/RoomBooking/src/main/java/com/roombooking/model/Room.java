package com.roombooking.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int RO_id;
	private String RO_roomNo;
	
	@OneToMany(mappedBy = "room", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Booking> bList=new ArrayList<>();
	public Room() {
	}

	public int getRO_id() {
		return RO_id;
	}

	public void setRO_id(int rO_id) {
		RO_id = rO_id;
	}

	public String getRO_roomNo() {
		return RO_roomNo;
	}

	public void setRO_roomNo(String rO_roomNo) {
		RO_roomNo = rO_roomNo;
	}

	public List<Booking> getbList() {
		return bList;
	}

	public void setbList(List<Booking> bList) {
		this.bList = bList;
	}

	

}

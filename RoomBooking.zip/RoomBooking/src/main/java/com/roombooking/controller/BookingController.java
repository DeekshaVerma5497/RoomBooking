package com.roombooking.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.roombooking.model.Booking;
import com.roombooking.model.DatePick;
import com.roombooking.model.Room;
import com.roombooking.service.ServiceM;

@Controller
public class BookingController {

	@Autowired(required = true)
	private ServiceM servicem;

	@RequestMapping("/")
	public ModelAndView homePage(Model model) {
		// servicem.createTables();
		List<Room> roomL = servicem.displayRooms();
		model.addAttribute("roomL", roomL);
		return new ModelAndView("Welcome", "roomL", roomL);
	}

	@RequestMapping(value = "/displayRDates")
	public ModelAndView displayRDates(Model model, HttpServletRequest request, HttpServletResponse response) {
		int roomNo = Integer.parseInt(request.getParameter("room"));
		List<DatePick> dateL = servicem.displayRDates(roomNo);
		List<Booking> bList=servicem.bookedRoom();
		model.addAttribute("bList",bList);
		model.addAttribute("dateL", dateL);
		model.addAttribute("roomNo", roomNo);
		
		return new ModelAndView("Book", "dateL", dateL);
	}

	@RequestMapping(value = "/bookRoom")
	public ModelAndView bookRoom(HttpServletRequest request, HttpServletResponse response) {
		int roomNo = Integer.parseInt(request.getParameter("val"));
		int bDate = Integer.parseInt(request.getParameter("id2"));
		System.out.println(roomNo+"and"+bDate);
		servicem.bookRoom(roomNo, bDate);
		return new ModelAndView("redirect:/");
	}

}

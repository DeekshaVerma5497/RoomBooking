package com.roombooking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DatePick {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int dateId;
	public int getDateId() {
		return dateId;
	}

	public void setDateId(int dateId) {
		this.dateId = dateId;
	}

	private String ADate;
	
	public DatePick() {
		
	}

	public String getADate() {
		return ADate;
	}

	public void setADate(String aDate) {
		ADate = aDate;
	}
	
	
	
}

package com.roombooking.dao;

import java.util.List;

import com.roombooking.model.Booking;
import com.roombooking.model.DatePick;
import com.roombooking.model.Room;

public interface BookingDAO {

	public List<DatePick> displayRDates(int roomNo);

	public void insertRoom(Room room);

	public List<Room> displayRooms();

	public void insertDate(DatePick datePick);

	public void bookRoom(int roomNo, String[] bDate);

	

	
	

}
